# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: signals.spec.ts >> signals preserve snapshots, decisions, version history and a conflicted reason
- Location: tests/signals.spec.ts:18:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByTestId('signal-detail').getByRole('status').filter({ hasText: 'Сигнал подтверждён аналитиком' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByTestId('signal-detail').getByRole('status').filter({ hasText: 'Сигнал подтверждён аналитиком' }) with timeout 5000ms
  - waiting for getByTestId('signal-detail').getByRole('status').filter({ hasText: 'Сигнал подтверждён аналитиком' })

```

```yaml
- alert
- link "Перейти к содержимому":
  - /url: "#main-content"
- complementary:
  - link "SAQ QURYLYS Рабочее место аналитика":
    - /url: /dashboard
  - text: МОНИТОРИНГ
  - navigation "Основная навигация":
    - link "Обзор":
      - /url: /dashboard
    - link "Объекты":
      - /url: /properties
    - link "Реклама":
      - /url: /advertisements
    - link "Проверка":
      - /url: /review
    - link "Сигналы":
      - /url: /signals
  - paragraph: Решение принимает человек Система формирует сигнал необходимости проверки.
  - text: А
  - strong: Аналитик
  - text: Аналитик
  - button "Выйти"
- banner:
  - text: Региональный мониторинг
  - strong: Усть-Каменогорск
  - search:
    - text: Найти объект или адрес
    - searchbox "Найти объект или адрес"
    - button "Найти объект"
  - text: DEMO · синтетические данные
- main:
  - paragraph: СИГНАЛЫ
  - heading "Сигналы для проверки" [level=1]
  - paragraph: Выберите объект, изучите сохранённые факты и откройте решение по конкретной версии. Сигнал помогает организовать проверку, но не устанавливает нарушение.
  - region "Три шага до понятного результата":
    - paragraph: КАК ЭТО РАБОТАЕТ
    - heading "Три шага до понятного результата" [level=2]
    - list:
      - listitem:
        - text: "1"
        - strong: Выберите сигнал
        - text: Нужный объект и версия находятся в списке.
      - listitem:
        - text: "2"
        - strong: Проверьте факты
        - text: Факторы, документы и исходники сохранены в снимке.
      - listitem:
        - text: "3"
        - strong: Откройте решение
        - text: Аналитик обосновывает решение, затем доступен PDF.
  - paragraph: ШАГ 1
  - heading "Выберите сигнал" [level=2]
  - text: "6"
  - paragraph: Откройте карточку, чтобы увидеть сохранённые факты и решение.
  - group: Фильтры Скрыты, пока не понадобятся
  - article:
    - text: Ожидает решения DEMO
    - heading "DEMO Ертіс · очередь 1" [level=3]
    - strong: "0"
    - text: "Зелёная Версия 6 Создан: 17 окт. 2026 г., 13:01"
    - button "Открыть версию 6" [pressed]
  - article:
    - text: Ожидает решения DEMO
    - heading "DEMO Ертіс · очередь 1" [level=3]
    - strong: "0"
    - text: "Зелёная Версия 5 Устарела Создан: 17 окт. 2026 г., 13:00"
    - button "Открыть версию 5"
  - article:
    - text: Ожидает решения DEMO
    - heading "DEMO Ертіс · очередь 1" [level=3]
    - strong: "0"
    - text: "Зелёная Версия 4 Устарела Создан: 17 окт. 2026 г., 12:59"
    - button "Открыть версию 4"
  - article:
    - text: Ожидает решения DEMO
    - heading "DEMO Ертіс · очередь 1" [level=3]
    - strong: "0"
    - text: "Зелёная Версия 3 Устарела Создан: 17 окт. 2026 г., 12:58"
    - button "Открыть версию 3"
  - article:
    - text: Ожидает решения DEMO
    - heading "DEMO Ертіс · очередь 1" [level=3]
    - strong: "0"
    - text: "Зелёная Версия 2 Устарела Создан: 17 окт. 2026 г., 12:57"
    - button "Открыть версию 2"
  - article:
    - text: Ожидает решения DEMO
    - heading "DEMO Ертіс · очередь 1" [level=3]
    - strong: "0"
    - text: "Зелёная Версия 1 Устарела Создан: 17 окт. 2026 г., 12:54"
    - button "Открыть версию 1"
  - navigation "Страницы сигналов":
    - button "Предыдущая страница" [disabled]
    - status: Страница 1 из 1
    - button "Следующая страница" [disabled]
  - paragraph: СОХРАНЁННЫЙ СНИМОК
  - heading "Сигнал · версия 6" [level=2]
  - paragraph:
    - link "DEMO Ертіс · очередь 1":
      - /url: /properties/7a971294-22a7-54c3-9656-262578a51e66
  - text: DEMO
  - strong: "0"
  - text: Зелёная
  - button "Обновить"
  - alert: Недопустимый источник запроса
  - text: Статус
  - strong: Ожидает решения
  - text: Актуальность
  - strong: Актуальная версия риска
  - text: Факторы
  - strong: 0 подтверждено из 0
  - text: Создан
  - strong: 17 окт. 2026 г., 13:01
  - strong: Что делать сейчас
  - paragraph: Проверьте факторы, документы и исходники. Затем добавьте понятное обоснование и сохраните решение.
  - paragraph: Сигнал необходимости проверки; не устанавливает факт правонарушения
  - paragraph: "DEMO: синтетические материалы и решения без юридической силы."
  - navigation "Разделы сигнала":
    - link "Обзор":
      - /url: "#signal-overview-8a52f573-259f-449c-bfc3-03c8bb428229"
    - link "Факты":
      - /url: "#signal-facts-8a52f573-259f-449c-bfc3-03c8bb428229"
    - link "Решение":
      - /url: "#signal-decision-8a52f573-259f-449c-bfc3-03c8bb428229"
    - link "PDF и версии":
      - /url: "#signal-output-8a52f573-259f-449c-bfc3-03c8bb428229"
  - text: "1"
  - paragraph: ОБЗОР
  - heading "Что важно знать" [level=3]
  - strong: Нужно уточнить
  - list:
    - listitem: Нет подтверждённого применимого основания на текущую дату. Это не подтверждает R1.
    - listitem: В общих сведениях готовность не указана. Датированные измерения — в доказательствах факторов.
  - paragraph: "Неподтверждённые коды: R1, R2, R3, R4, R5, R6. Зелёная зона не подтверждает безопасность объекта."
  - group: Служебные данные снимка
  - text: "2"
  - paragraph: ФАКТЫ
  - heading "Проверяемые материалы" [level=3]
  - paragraph: Откройте каждую группу и сверьте основания решения. Эти данные относятся только к выбранной версии.
  - group: Факторы риска 0
  - group: Правовые основания 0
  - group: Доказательства и исходники 0
  - text: "3"
  - paragraph: РЕШЕНИЕ
  - heading "Решение по этой версии" [level=3]
  - text: Обоснование решения по сигналу
  - textbox "Обоснование решения по сигналу": "DEMO: проверены сохранённые материалы; сигнал направлен на дополнительную проверку и не устанавливает нарушение"
  - paragraph: Кратко укажите, какие материалы проверены и почему выбрано это решение. При изменении фактов нужен новый снимок.
  - button "Подтвердить сигнал"
  - button "Вернуть на доработку"
  - text: "4"
  - paragraph: РЕЗУЛЬТАТ
  - heading "PDF и версии" [level=3]
  - heading "PDF этой версии" [level=4]
  - paragraph: PDF ещё не запрошен
  - button "Подготовить PDF"
  - text: PDF хранит снимок и решение этой версии. Поздние изменения его не переписывают.
  - heading "История объекта" [level=4]
  - button "Создать новую версию из текущих фактов"
  - link "Предыдущая версия":
    - /url: /signals?signal_id=6a58bf35-3ae2-45b7-bfe6-da01a69d6b21
  - paragraph:
    - link "Версия 6":
      - /url: /signals?signal_id=8a52f573-259f-449c-bfc3-03c8bb428229
    - text: Ожидает решения · 17 окт. 2026 г., 13:01
  - paragraph:
    - link "Версия 5":
      - /url: /signals?signal_id=6a58bf35-3ae2-45b7-bfe6-da01a69d6b21
    - text: Ожидает решения · устарела · 17 окт. 2026 г., 13:00
  - paragraph:
    - link "Версия 4":
      - /url: /signals?signal_id=761db750-877f-4f46-93ff-670de033312b
    - text: Ожидает решения · устарела · 17 окт. 2026 г., 12:59
  - paragraph:
    - link "Версия 3":
      - /url: /signals?signal_id=aeff87d7-6be7-4a75-adc2-bf8a9c9346f6
    - text: Ожидает решения · устарела · 17 окт. 2026 г., 12:58
  - paragraph:
    - link "Версия 2":
      - /url: /signals?signal_id=3f0a555e-81d3-4d62-afdd-13efca491d66
    - text: Ожидает решения · устарела · 17 окт. 2026 г., 12:57
  - paragraph:
    - link "Версия 1":
      - /url: /signals?signal_id=b95f60e6-0320-4a38-b96d-120598ca85c5
    - text: Ожидает решения · устарела · 17 окт. 2026 г., 12:54
- contentinfo: SAQ QURYLYS · Прототип · Сигнал не устанавливает факт правонарушения
```

# Test source

```ts
  1   | import { test, expect, type Page } from "@playwright/test";
  2   | import { randomUUID } from "node:crypto";
  3   | import { mkdir } from "node:fs/promises";
  4   | import { login } from "./support";
  5   | 
  6   | async function post(page: Page, path: string, data: unknown) {
  7   |   const csrf = await (await page.request.get("/api/v1/auth/csrf")).json();
  8   |   return page.request.post(`/api/v1${path}`, {
  9   |     headers: {
  10  |       Origin: "http://localhost:3000",
  11  |       "X-CSRF-Token": csrf.csrf_token,
  12  |       "Idempotency-Key": randomUUID(),
  13  |     },
  14  |     data,
  15  |   });
  16  | }
  17  | 
  18  | test("signals preserve snapshots, decisions, version history and a conflicted reason", async ({
  19  |   page,
  20  | }) => {
  21  |   test.setTimeout(120_000);
  22  |   await login(page);
  23  |   const registry = await (
  24  |     await page.request.get("/api/v1/properties?page_size=100")
  25  |   ).json();
  26  |   const property = registry.items.find((row: { name: string }) =>
  27  |     row.name.includes("Ертіс"),
  28  |   );
  29  |   const current = await (
  30  |     await page.request.get(`/api/v1/properties/${property.id}`)
  31  |   ).json();
  32  |   const history = await (
  33  |     await page.request.get(`/api/v1/signals?property_id=${property.id}`)
  34  |   ).json();
  35  |   const latest = history.items[0];
  36  |   const created = await post(page, "/signals", {
  37  |     property_id: property.id,
  38  |     expected_risk_revision: current.property.risk.revision,
  39  |     ...(latest ? { previous_signal_id: latest.id } : {}),
  40  |   });
  41  |   expect(created.status()).toBe(201);
  42  |   const first = await created.json();
  43  |   expect(first.state).toBe("DRAFT");
  44  |   await page.goto(`/signals?signal_id=${first.id}`);
  45  |   const panel = page.getByTestId("signal-detail");
  46  |   await expect(
  47  |     panel.getByRole("heading", {
  48  |       name: `Сигнал · версия ${first.version}`,
  49  |       exact: true,
  50  |     }),
  51  |   ).toBeVisible();
  52  |   await expect(panel).toContainText(
  53  |     "Сигнал необходимости проверки; не устанавливает факт правонарушения",
  54  |   );
  55  |   await expect(
  56  |     panel.getByText("Ожидает решения", { exact: true }),
  57  |   ).toBeVisible();
  58  |   await expect(
  59  |     panel.getByRole("button", { name: "Подтвердить сигнал", exact: true }),
  60  |   ).toBeDisabled();
  61  |   await panel
  62  |     .getByLabel("Обоснование решения по сигналу")
  63  |     .fill(
  64  |       "DEMO: проверены сохранённые материалы; сигнал направлен на дополнительную проверку и не устанавливает нарушение",
  65  |     );
  66  |   await panel
  67  |     .getByRole("button", { name: "Подтвердить сигнал", exact: true })
  68  |     .click();
  69  |   await expect(
  70  |     panel
  71  |       .getByRole("status")
  72  |       .filter({ hasText: "Сигнал подтверждён аналитиком" }),
> 73  |   ).toBeVisible();
      |     ^ Error: expect(locator).toBeVisible() failed
  74  |   await expect(
  75  |     panel.getByText("Подтверждён аналитиком", { exact: true }),
  76  |   ).toBeVisible();
  77  |   await expect(
  78  |     panel.getByRole("button", { name: "Подтвердить сигнал", exact: true }),
  79  |   ).toHaveCount(0);
  80  |   await expect(
  81  |     panel.getByRole("link", { name: "Скачать PDF этой версии", exact: true }),
  82  |   ).toBeVisible({ timeout: 60_000 });
  83  |   const pdf = await page.request.get(`/api/v1/signals/${first.id}/pdf`);
  84  |   expect(pdf.status()).toBe(200);
  85  |   expect(pdf.headers()["content-type"]).toContain("application/pdf");
  86  |   expect((await pdf.body()).subarray(0, 5).toString()).toBe("%PDF-");
  87  |   const before = await (
  88  |     await page.request.get(`/api/v1/signals/${first.id}`)
  89  |   ).json();
  90  | 
  91  |   await panel
  92  |     .getByRole("button", {
  93  |       name: "Создать новую версию из текущих фактов",
  94  |       exact: true,
  95  |     })
  96  |     .click();
  97  |   await expect(page).not.toHaveURL(new RegExp(`signal_id=${first.id}$`));
  98  |   const secondId = new URL(page.url()).searchParams.get("signal_id")!;
  99  |   await expect(
  100 |     panel.getByRole("heading", {
  101 |       name: `Сигнал · версия ${first.version + 1}`,
  102 |       exact: true,
  103 |     }),
  104 |   ).toBeVisible();
  105 |   const retainedReason =
  106 |     "DEMO: причина должна сохраниться при конфликте с новой версией";
  107 |   await panel.getByLabel("Обоснование решения по сигналу").fill(retainedReason);
  108 |   const thirdResponse = await post(page, "/signals", {
  109 |     property_id: property.id,
  110 |     previous_signal_id: secondId,
  111 |     expected_risk_revision: current.property.risk.revision,
  112 |   });
  113 |   expect(thirdResponse.status()).toBe(201);
  114 |   const third = await thirdResponse.json();
  115 |   const conflict = page.waitForResponse(
  116 |     (response) =>
  117 |       response.url().endsWith(`/signals/${secondId}/decision`) &&
  118 |       response.request().method() === "POST",
  119 |   );
  120 |   await panel
  121 |     .getByRole("button", { name: "Подтвердить сигнал", exact: true })
  122 |     .click();
  123 |   expect((await conflict).status()).toBe(409);
  124 |   await expect(panel).toContainText("Устарел для текущего решения");
  125 |   await expect(panel.getByLabel("Обоснование решения по сигналу")).toHaveValue(
  126 |     retainedReason,
  127 |   );
  128 |   await expect(
  129 |     panel.getByRole("button", { name: "Подтвердить сигнал", exact: true }),
  130 |   ).toBeDisabled();
  131 | 
  132 |   await panel
  133 |     .getByRole("link", { name: `Версия ${third.version}`, exact: true })
  134 |     .click();
  135 |   await expect(
  136 |     panel.getByRole("heading", {
  137 |       name: `Сигнал · версия ${third.version}`,
  138 |       exact: true,
  139 |     }),
  140 |   ).toBeVisible();
  141 |   await panel
  142 |     .getByLabel("Обоснование решения по сигналу")
  143 |     .fill(
  144 |       "DEMO: вернуть материал для дополнения неизвестных сведений; исходный снимок сохраняется",
  145 |     );
  146 |   await panel
  147 |     .getByRole("button", { name: "Вернуть на доработку", exact: true })
  148 |     .click();
  149 |   await expect(
  150 |     panel.getByText("Возвращён на доработку", { exact: true }),
  151 |   ).toBeVisible();
  152 |   const after = await (
  153 |     await page.request.get(`/api/v1/signals/${first.id}`)
  154 |   ).json();
  155 |   expect(after.snapshot).toEqual(before.snapshot);
  156 |   expect(after.decisions).toEqual(before.decisions);
  157 |   expect(after.signal.state).toBe("CONFIRMED");
  158 |   expect(after.signal.is_stale).toBe(true);
  159 | 
  160 |   await page.locator(".signal-filters summary").click();
  161 |   await page.getByLabel("Статус сигнала").selectOption("RETURNED");
  162 |   await page.getByLabel("Объект сигнала").selectOption(property.id);
  163 |   await expect(page.getByLabel("Очередь сигналов")).toContainText(
  164 |     `Версия ${third.version}`,
  165 |   );
  166 |   await page.setViewportSize({ width: 390, height: 844 });
  167 |   await expect(page.getByLabel("Объект сигнала")).toBeVisible();
  168 |   expect(
  169 |     await page.evaluate(
  170 |       () => document.documentElement.scrollWidth <= window.innerWidth,
  171 |     ),
  172 |   ).toBe(true);
  173 |   await mkdir("../output/qa", { recursive: true });
```